import matplotlib.pyplot as plt

def get_pixel_coordinates_from_click(imagePath, outputfilename):
    im = plt.imread(imagePath)
    ax = plt.gca()
    fig = plt.gcf()
    implot = ax.imshow(im)
    filepath = outputfilename + ".txt"
    def onclick(event,filepath=filepath):
        if event.xdata != None and event.ydata != None:
            with open(filepath, "a") as text_file:
                print("{}\t{}".format(event.xdata, event.ydata),file=text_file)
  
    cid = fig.canvas.mpl_connect('button_press_event', onclick)
    plt.show()

#  ------------------------- Örnek Kullanım ----------------------------
# image_path_1 --- > "Koordinatlarını ölçmek istediğin 1.görüntün nerede, onun yolunu yazmalısın."
# image_path_2 --- > "Koordinatlarını ölçmek istediğin 2.görüntün nerede, onun yolunu yazmalısın."
# measured_coordinates_1 --- > "1.görüntünün koordinatları nereye hangi dosya adıyla kaydedilsin."
# measured_coordinates_2 --- > "1.görüntünün koordinatları nereye hangi dosya adıyla kaydedilsin."
#   
if __name__ == "__main__":
    image_path_1 = "D:\\HACETTEPE\\fotogrametri\\fotograf3.jpeg"
    image_path_2 = "D:\\HACETTEPE\\fotogrametri\\fotograf4.jpeg"
    measured_coordinates_1 = "test3_points" # bu scriptin olduğu konuma test1_points.txt olarak kaydedecek.
    measured_coordinates_2 = "test4_points" # bu scriptin olduğu konuma test2_points.txt olarak kaydedecek.
    # önce 1.görüntü açılacak ölçmek istediğiniz noktalara tıklayın ve çarpı işaretine tıklayın, ardından ikinci görüntü açılacak
    # 1.görüntüde seçtiğiniz noktaları ikinci görüntüde de seçin ve çarpıya tıklayın. Ölçtüğünüz noktalar txt olarak belirttiğiniz
    # konuma, belirttiğiniz isimle kaydedilmiş olacak.
    get_pixel_coordinates_from_click(image_path_1, measured_coordinates_1)
    get_pixel_coordinates_from_click(image_path_2, measured_coordinates_2)
